import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";
import { useNavigate } from "react-router-dom";

const SearchBar = () => {
  const [query, setQuery] = useState("");
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      navigate(`/chat?q=${encodeURIComponent(query.trim())}`);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <form onSubmit={handleSearch} className="relative">
        <div className="relative flex items-center bg-search-bg border-2 border-search-border rounded-full shadow-elegant transition-smooth hover:shadow-lg focus-within:shadow-lg focus-within:border-primary/50">
          <Input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Ask anything about our tech stack, insights and discussions"
            className="flex-1 border-0 bg-transparent px-8 py-6 text-lg placeholder:text-muted-foreground focus-visible:ring-0 focus-visible:ring-offset-0 rounded-full"
          />
          <Button
            type="submit"
            size="sm"
            className="absolute right-3 bg-primary hover:bg-primary-glow rounded-full w-12 h-12 p-0"
          >
            <Search className="w-5 h-5" />
          </Button>
        </div>
      </form>
    </div>
  );
};

export default SearchBar;
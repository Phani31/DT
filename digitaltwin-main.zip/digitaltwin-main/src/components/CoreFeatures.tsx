import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Server, 
  Brain, 
  Database, 
  Users, 
  MessageCircle, 
  Search, 
  Activity, 
  BarChart3,
  Container,
  Layers,
  Globe,
  Zap,
  BookOpen,
  FileText,
  Network,
  RefreshCw
} from "lucide-react";

const coreFeatures = [
  {
    title: "FastAPI Framework",
    description: "RESTful API endpoints for chat, search, health monitoring, analytics, and agent communication.",
    details: [
      "RESTful API endpoints for chat, search, health monitoring, analytics, and agent communication",
      "Containerized via Docker Compose for local/development deployment",
      "Scalable architecture designed for production deployment"
    ],
    icon: Server,
    color: "from-blue-500 to-blue-600",
    badges: ["REST API", "Docker", "Scalable"]
  },
  {
    title: "Natural Language Understanding & Processing",
    description: "Advanced NLU capabilities for understanding user queries and intent recognition.",
    details: [
      "Advanced NLU capabilities for understanding user queries and intent recognition",
      "NLP processing for text analysis, entity extraction, and semantic understanding",
      "Context-aware conversation handling for maintaining dialogue state"
    ],
    icon: Brain,
    color: "from-purple-500 to-purple-600",
    badges: ["NLU", "NLP", "Context-Aware"]
  },
  {
    title: "Knowledge Base & Vector Database",
    description: "Vector database for semantic search and similarity matching.",
    details: [
      "Vector database for semantic search and similarity matching",
      "Knowledge base integration for storing and retrieving domain-specific information",
      "Document indexing and retrieval system for accessing relevant information"
    ],
    icon: Database,
    color: "from-green-500 to-green-600",
    badges: ["Vector DB", "Semantic Search", "Indexing"]
  },
  {
    title: "Agent System",
    description: "Multi-agent communication framework for specialized task handling.",
    details: [
      "Multi-agent communication framework for specialized task handling",
      "Agent orchestration for complex query resolution",
      "Feedback loop system for continuous improvement of agent responses"
    ],
    icon: Users,
    color: "from-orange-500 to-orange-600",
    badges: ["Multi-Agent", "Orchestration", "Feedback"]
  },
  {
    title: "Memory and Context Management",
    description: "Maintains a complete record of all user interactions and system responses.",
    details: [
      "Conversation History Storage: Maintains a complete record of all user interactions and system responses",
      "Context Tracking: Preserves context across multiple turns of conversation for coherent dialogue",
      "Memory Prioritization: Intelligently prioritizes relevant information from past conversations",
      "Long-term Memory Storage: Persists important information across sessions for returning users"
    ],
    icon: MessageCircle,
    color: "from-indigo-500 to-indigo-600",
    badges: ["History", "Context", "Memory"]
  },
  {
    title: "MCP (Model Context Protocol) Support",
    description: "Standardized protocol for information exchange between AI agents.",
    details: [
      "Agent Communication Framework: Standardized protocol for information exchange between AI agents",
      "Context Preservation: Maintains coherent context when transferring control between agents",
      "Specialized Agent Routing: Directs queries to domain-specific expert agents as needed",
      "Collaborative Problem Solving: Enables multiple agents to work together on complex tasks"
    ],
    icon: Network,
    color: "from-red-500 to-red-600",
    badges: ["Protocol", "Routing", "Collaborative"]
  }
];

const CoreFeatures = () => {
  const [expandedCards, setExpandedCards] = useState<number[]>([]);

  const toggleExpanded = (index: number) => {
    setExpandedCards(prev => 
      prev.includes(index) 
        ? prev.filter(i => i !== index)
        : [...prev, index]
    );
  };
  return (
    <div className="w-full max-w-6xl mx-auto mt-16">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold mb-4 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
          Core Features
        </h2>
        <p className="text-muted-foreground">
          Powered by cutting-edge AI technology and modern architecture
        </p>
      </div>

      {/* Main Core Features */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {coreFeatures.map((feature, index) => (
          <Card key={index} className="group cursor-pointer transition-smooth hover:shadow-lg hover:-translate-y-1 border-border/50 text-center">
            <CardHeader className="pb-2 px-4 pt-4">
              <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${feature.color} flex items-center justify-center mx-auto mb-2 group-hover:scale-110 transition-smooth`}>
                <feature.icon className="w-4 h-4 text-white" />
              </div>
              <div className="flex flex-wrap justify-center gap-1 mb-2">
                {feature.badges.map((badge, badgeIndex) => (
                  <Badge key={badgeIndex} variant="secondary" className="text-xs">
                    {badge}
                  </Badge>
                ))}
              </div>
              <CardTitle className="text-sm font-medium leading-tight mb-1">{feature.title}</CardTitle>
              <CardDescription className="text-xs leading-tight">{feature.description}</CardDescription>
            </CardHeader>
            <CardContent className="pt-0 px-4 pb-3">
              {expandedCards.includes(index) && (
                <ul className="space-y-1 mb-2 text-left">
                  {feature.details.map((detail, detailIndex) => (
                    <li key={detailIndex} className="flex items-start space-x-2 text-xs text-muted-foreground">
                      <div className="w-1 h-1 rounded-full bg-primary mt-1 flex-shrink-0"></div>
                      <span className="leading-tight">{detail}</span>
                    </li>
                  ))}
                </ul>
              )}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => toggleExpanded(index)}
                className="text-primary hover:text-primary-glow text-xs p-0 h-auto font-medium"
              >
                {expandedCards.includes(index) ? "Show less" : "Show more"}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default CoreFeatures;
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, FileText, MessageSquare, PenTool } from "lucide-react";

const quickActions = [
  {
    title: "Jira",
    description: "Create and track tickets",
    icon: MessageSquare,
    color: "from-blue-500 to-blue-600"
  },
  {
    title: "Schedule a Meeting",
    description: "Book time with Ramki",
    icon: Calendar,
    color: "from-green-500 to-green-600"
  },
  {
    title: "Confluence",
    description: "Access documentation",
    icon: FileText,
    color: "from-purple-500 to-purple-600"
  },
  {
    title: "Blogin",
    description: "Read latest insights",
    icon: PenTool,
    color: "from-orange-500 to-orange-600"
  }
];

const QuickActions = () => {
  return (
    <div className="w-full max-w-4xl mx-auto">
      <h3 className="text-lg font-semibold mb-4 text-foreground">Quick Actions</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {quickActions.map((action, index) => (
          <Card key={index} className="group cursor-pointer transition-smooth hover:shadow-lg hover:-translate-y-1 border-border/50">
            <CardHeader className="pb-3">
              <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${action.color} flex items-center justify-center mb-2 group-hover:scale-110 transition-smooth`}>
                <action.icon className="w-5 h-5 text-white" />
              </div>
              <CardTitle className="text-base">{action.title}</CardTitle>
              <CardDescription className="text-sm">{action.description}</CardDescription>
            </CardHeader>
            <CardContent className="pt-0">
              <Button variant="outline" size="sm" className="w-full">
                Open
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default QuickActions;
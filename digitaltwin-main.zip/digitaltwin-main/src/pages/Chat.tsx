import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { ThumbsUp, ThumbsDown, Send } from "lucide-react";
import Navigation from "@/components/Navigation";
import QuickActions from "@/components/QuickActions";

const Chat = () => {
  const [searchParams] = useSearchParams();
  const [currentQuery, setCurrentQuery] = useState("");
  const [newQuery, setNewQuery] = useState("");
  const [answer, setAnswer] = useState("");
  const [liked, setLiked] = useState<boolean | null>(null);

  useEffect(() => {
    const query = searchParams.get('q');
    if (query) {
      setCurrentQuery(query);
      // Simulate getting an answer
      setAnswer(`Based on my knowledge and experience, here's what I can tell you about "${query}":

This is a comprehensive response from Ramki's digital twin. I've analyzed your question and drawn from my extensive background in technology, leadership, and industry insights to provide you with the most relevant and actionable information.

The key points to consider are:
1. Strategic approach to the problem
2. Technical considerations and best practices
3. Implementation roadmap
4. Risk mitigation strategies

Would you like me to elaborate on any specific aspect of this response?`);
    }
  }, [searchParams]);

  const handleNewQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (newQuery.trim()) {
      window.location.href = `/chat?q=${encodeURIComponent(newQuery.trim())}`;
    }
  };

  const handleLike = () => {
    setLiked(liked === true ? null : true);
  };

  const handleDislike = () => {
    setLiked(liked === false ? null : false);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <main className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Question */}
        <div className="mb-8">
          <div className="bg-muted/50 rounded-lg p-4 border border-border/50">
            <p className="text-sm text-muted-foreground mb-1">You asked:</p>
            <p className="text-lg font-medium">{currentQuery}</p>
          </div>
        </div>

        {/* Answer */}
        <div className="mb-8">
          <Card className="border-border/50">
            <CardContent className="p-6">
              <div className="prose prose-gray max-w-none">
                <p className="text-foreground leading-relaxed whitespace-pre-line">
                  {answer}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Like/Dislike Buttons */}
        <div className="flex items-center space-x-4 mb-8">
          <Button
            variant={liked === true ? "default" : "outline"}
            size="sm"
            onClick={handleLike}
            className="flex items-center space-x-2"
          >
            <ThumbsUp className="w-4 h-4" />
            <span>Helpful</span>
          </Button>
          <Button
            variant={liked === false ? "destructive" : "outline"}
            size="sm"
            onClick={handleDislike}
            className="flex items-center space-x-2"
          >
            <ThumbsDown className="w-4 h-4" />
            <span>Not helpful</span>
          </Button>
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <QuickActions />
        </div>

        {/* Next Question Bar */}
        <div className="sticky bottom-4">
          <form onSubmit={handleNewQuestion} className="relative">
            <div className="relative flex items-center bg-card border border-border rounded-full shadow-elegant">
              <Input
                type="text"
                value={newQuery}
                onChange={(e) => setNewQuery(e.target.value)}
                placeholder="Ask another question..."
                className="flex-1 border-0 bg-transparent px-6 py-4 text-base placeholder:text-muted-foreground focus-visible:ring-0 focus-visible:ring-offset-0 rounded-full"
              />
              <Button
                type="submit"
                size="sm"
                className="absolute right-2 bg-primary hover:bg-primary-glow rounded-full w-10 h-10 p-0"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </form>
        </div>
      </main>
    </div>
  );
};

export default Chat;
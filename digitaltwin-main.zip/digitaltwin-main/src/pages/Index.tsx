import Navigation from "@/components/Navigation";
import SearchBar from "@/components/SearchBar";
import CoreFeatures from "@/components/CoreFeatures";
import zetaLogo from "@/assets/zeta-logo.png";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <main className="flex-1 flex flex-col items-center justify-center px-4 py-20">
        <div className="text-center mb-12 max-w-3xl">
          <h1 className="text-5xl font-bold mb-6 bg-gradient-to-r from-primary via-accent to-primary-glow bg-clip-text text-transparent">
            Ramki Digital Twin
          </h1>
          <p className="text-xl text-muted-foreground mb-2">
            Ask anything about our tech stack, insights and discussions
          </p>
          <p className="text-sm text-muted-foreground">
            Knowledge sourced from Ramki's office hours calls
          </p>
        </div>
        
        <div className="w-full max-w-2xl">
          <SearchBar />
        </div>
        
        <div className="mt-12 text-center">
          <p className="text-sm text-muted-foreground mb-4">Popular topics:</p>
          <div className="flex flex-wrap justify-center gap-2">
            {["AI Strategy", "Digital Transformation", "Team Leadership", "Technology Trends"].map((topic) => (
              <span key={topic} className="px-3 py-1 bg-muted/50 text-muted-foreground rounded-full text-sm hover:bg-muted transition-smooth cursor-pointer">
                {topic}
              </span>
            ))}
          </div>
        </div>
        
        <CoreFeatures />
      </main>
      
      <footer className="border-t border-border/50 py-6 px-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <img src={zetaLogo} alt="Zeta Logo" className="h-8 w-8" />
          </div>
          <div className="text-sm text-muted-foreground text-center flex-1">
            Powered by Enterprise Apps & Productivity Team. © 2025 Zeta. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;

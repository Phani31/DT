nvm use 18.20.3
npm install
npm run build